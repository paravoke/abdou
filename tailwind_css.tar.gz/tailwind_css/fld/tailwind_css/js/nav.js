let k=0;
function disp(){ 
if ((k % 2)==0) {
document.getElementById("navShow").style.display = "grid";
k++;

}
 else {
	document.getElementById("navShow").style.display = "none";
	k++;

}

}