package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {
    public EditText zoneCelsus, zonefore;
    public Button btncelsus, btnfore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        zoneCelsus = (EditText) findViewById(R.id.cels);
        zonefore = (EditText) findViewById(R.id.fah);
        btncelsus = (Button) findViewById(R.id.celsbtn);
        btnfore = (Button) findViewById(R.id.fahbtn);


        btncelsus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (zoneCelsus.getText().toString().isEmpty()) {
                    Toast affiche_toast = Toast.makeText(getApplicationContext(), "Remplir le champ 'Celusus'",Toast.LENGTH_LONG);

                    affiche_toast.show();
                } else {
                    double cels = Double.parseDouble(zoneCelsus.getText().toString());
                    double result = (cels * 9 / 5 + 32);
                    zonefore.setText(String.valueOf(result));
                }
            }

        });
    }
}